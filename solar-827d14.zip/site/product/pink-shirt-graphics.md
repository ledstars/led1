---
tax-category: "standard-taxable"
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db3919f6677179b8_Watch-8.png"
  alt: ""
created-on: "2019-03-13T23:07:14.970Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db3919646f7177e8_15.jpg"
  alt: ""
name: "Woman's Watch 1"
slug: "pink-shirt-graphics"
shippable: true
updated-on: "2020-03-12T00:22:38.282Z"
default-sku: "site/sku/pink-shirt-graphics.md"
description: "I marketed pens - on the phone. But the beauty of the gig was that you had to call these strangers and say, 'Hi, how ya doing?' You made up a name, like, 'Hey, it's Edward Quartermaine from California. You're eligible to receive this grandfather clock or a trip to Tahiti."
category:
  - "site/category/stain-steel.md"
  - "site/category/analogue.md"
  - "site/category/last-act.md"
published-on: "2021-02-25T22:33:23.482Z"
tags: "product"
layout: "single-product.html"
---


