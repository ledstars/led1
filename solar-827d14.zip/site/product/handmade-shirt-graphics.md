---
tax-category: "standard-taxable"
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db3919038d717902_8.jpg"
  alt: ""
created-on: "2019-03-13T22:58:04.332Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db391968d9717971_3.jpg"
  alt: ""
name: "Men's Watch 3"
slug: "handmade-shirt-graphics"
shippable: true
updated-on: "2020-03-11T18:10:51.046Z"
default-sku: "site/sku/handmade-shirt-graphics.md"
description: "I marketed pens - on the phone. But the beauty of the gig was that you had to call these strangers and say, 'Hi, how ya doing?' You made up a name, like, 'Hey, it's Edward Quartermaine from California. You're eligible to receive this grandfather clock or a trip to Tahiti."
category:
  - "site/category/stain-steel.md"
  - "site/category/analogue.md"
  - "site/category/most-popular.md"
published-on: "2021-02-25T22:33:23.482Z"
tags: "product"
layout: "single-product.html"
---


