---
tax-category: "standard-taxable"
_archived: false
_draft: false
gallery-image-1:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db39194cf17179ae_Watch-16.png"
  alt: ""
created-on: "2019-03-13T20:24:58.448Z"
gallery-image-2:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db39191d9a717800_18.jpg"
  alt: ""
name: "Boy's Watch 1"
slug: "daniele-sun-glasses"
shippable: true
updated-on: "2020-03-12T00:26:35.321Z"
default-sku: "site/sku/daniele-sun-glasses.md"
description: "I marketed pens - on the phone. But the beauty of the gig was that you had to call these strangers and say, 'Hi, how ya doing?' You made up a name, like, 'Hey, it's Edward Quartermaine from California. You're eligible to receive this grandfather clock or a trip to Tahiti."
category:
  - "site/category/leather.md"
  - "site/category/analogue.md"
  - "site/category/last-act.md"
published-on: "2021-02-25T22:33:23.482Z"
tags: "product"
layout: "single-product.html"
---


