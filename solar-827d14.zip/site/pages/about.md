---
title: "About"
permalink: "{{ page.fileSlug }}/index.html"
layout: "about.html"
slug: "about"
tags: "pages"
seo:
  title: "Arctic - Webflow Ecommerce Website Template"
  description: "Welcome to Arctic Webflow Ecommerce website template. Arctic is an incredible ecommerce website template designed with a unique color combination and highly attractive layout structure."
  og_title: "Arctic - Webflow Ecommerce Website Template"
  og_description: "Welcome to Arctic Webflow Ecommerce website template. Arctic is an incredible ecommerce website template designed with a unique color combination and highly attractive layout structure."
  og_type: "website"
  twitter_card: "summary_large_image"
---


