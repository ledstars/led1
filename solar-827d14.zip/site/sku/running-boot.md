---
_archived: false
_draft: false
created-on: "2019-03-13T22:50:04.462Z"
width: 100
length: 90
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db39192f3c7179b3_Watch-7.png"
  alt: ""
height: 60
price:
  value: 50000
  unit: "USD"
name: "Men's Watch 4"
slug: "running-boot"
product: "site/product/running-boot.md"
more-images: []
updated-on: "2020-03-12T00:23:24.122Z"
sku-values: {}
weight: 120
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


