---
_archived: false
_draft: false
created-on: "2019-03-13T23:09:00.286Z"
width: 23
length: 56
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db3919c7717179a3_Watch-2.png"
  alt: ""
height: 43
price:
  value: 34500
  unit: "USD"
name: "Men's Watch 2"
slug: "darkshirt-graphics"
product: "site/product/darkshirt-graphics.md"
more-images: []
updated-on: "2020-03-12T00:16:22.122Z"
sku-values: {}
weight: 33
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


