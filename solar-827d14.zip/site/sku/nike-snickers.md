---
_archived: false
_draft: false
created-on: "2019-03-13T22:46:49.271Z"
width: 100
length: 70
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db391953827179a8_Watch-8.png"
  alt: ""
height: 30
price:
  value: 45000
  unit: "USD"
name: "Woman's Watch 3"
slug: "nike-snickers"
product: "site/product/nike-snickers.md"
more-images: []
updated-on: "2020-03-12T00:24:50.825Z"
sku-values: {}
weight: 120
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


