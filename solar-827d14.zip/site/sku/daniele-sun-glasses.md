---
_archived: false
_draft: false
created-on: "2019-03-13T20:24:58.638Z"
width: 60
length: 20
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db39197b487179af_Watch-15.png"
  alt: ""
height: 40
price:
  value: 115000
  unit: "USD"
name: "Boy's Watch 1"
slug: "daniele-sun-glasses"
product: "site/product/daniele-sun-glasses.md"
more-images: []
updated-on: "2020-03-12T00:26:34.256Z"
sku-values: {}
weight: 100
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


