---
_archived: false
_draft: false
created-on: "2019-03-13T22:58:04.584Z"
width: 40
length: 5
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db3919b11d7179a5_Watch-4.png"
  alt: ""
height: 50
price:
  value: 20000
  unit: "USD"
name: "Men's Watch 3"
slug: "handmade-shirt-graphics"
product: "site/product/handmade-shirt-graphics.md"
more-images: []
updated-on: "2020-03-11T18:10:49.968Z"
sku-values: {}
weight: 20
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


