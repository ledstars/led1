---
_archived: false
_draft: false
created-on: "2019-03-13T23:10:03.482Z"
width: 43
length: 56
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db391953437179a2_Watch-1.png"
  alt: ""
height: 55
price:
  value: 12300
  unit: "USD"
name: "Men's Watch 1"
slug: "yellow-shirt-graphics"
product: "site/product/yellow-shirt-graphics.md"
more-images: []
updated-on: "2020-03-12T00:16:03.077Z"
sku-values: {}
weight: 23
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


