---
_archived: false
_draft: false
created-on: "2019-03-15T02:09:32.162Z"
width: 60
length: 20
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db3919fb157179ab_Watch-5.png"
  alt: ""
height: 40
price:
  value: 45000
  unit: "USD"
name: "Men's Watch 6"
slug: "mens-watches-6"
product: "site/product/mens-watches-6.md"
more-images: []
updated-on: "2020-03-12T00:14:39.861Z"
sku-values: {}
weight: 100
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


