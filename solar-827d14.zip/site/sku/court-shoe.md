---
_archived: false
_draft: false
created-on: "2019-03-13T22:55:01.941Z"
width: 160
length: 40
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db391927487179a6_Watch-6.png"
  alt: ""
height: 120
price:
  value: 55000
  unit: "USD"
name: "Woman's Watch 2"
slug: "court-shoe"
product: "site/product/court-shoe.md"
more-images: []
updated-on: "2020-03-12T00:22:56.340Z"
sku-values: {}
weight: 117
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


