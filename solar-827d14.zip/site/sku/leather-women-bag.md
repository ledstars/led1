---
_archived: false
_draft: false
created-on: "2019-03-13T20:26:00.609Z"
width: 60
length: 20
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db39190c197179b1_Watch-12.png"
  alt: ""
height: 40
price:
  value: 125000
  unit: "USD"
name: "Girl's Watch 2"
slug: "leather-women-bag"
product: "site/product/leather-women-bag.md"
more-images: []
updated-on: "2020-03-12T00:26:13.689Z"
sku-values: {}
weight: 100
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


