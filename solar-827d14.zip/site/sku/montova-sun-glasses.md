---
_archived: false
_draft: false
created-on: "2019-03-13T20:23:49.495Z"
width: 60
length: 20
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db391905097179b0_Watch-14.png"
  alt: ""
height: 40
price:
  value: 75000
  unit: "USD"
name: "Boy's Watch 2"
slug: "montova-sun-glasses"
product: "site/product/montova-sun-glasses.md"
more-images: []
updated-on: "2020-03-12T00:26:56.192Z"
sku-values: {}
weight: 100
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


