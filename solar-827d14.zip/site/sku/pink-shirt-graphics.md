---
_archived: false
_draft: false
created-on: "2019-03-13T23:07:15.189Z"
width: 23
length: 65
main-image:
  url: "https://uploads-ssl.webflow.com/5f85b7e2db3919c9147177df/5f85b7e2db391973307179a4_Watch-3.png"
  alt: ""
height: 45
price:
  value: 26000
  unit: "USD"
name: "Woman's Watch 1"
slug: "pink-shirt-graphics"
product: "site/product/pink-shirt-graphics.md"
more-images: []
updated-on: "2020-03-12T00:22:37.759Z"
sku-values: {}
weight: 12
sku: "36065"
published-on: "2021-02-25T22:33:23.482Z"
tags: "sku"
layout: "single-sku.11ty.js"
---


